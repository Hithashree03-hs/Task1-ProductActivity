import { useEffect, useState } from 'react';

import './App.css';



const API_BASE_URL = 'https://task1-productactivity.onrender.com/api';



async function readJson(response) {

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {

    const error = new Error(data.message || `Request failed (${response.status}).`);
    error.status = response.status;
    throw error;

  }

  return data;

}



async function postWithFallback(paths, options) {
  let lastError = null;
  for (const path of paths) {
    try {
      const response = await fetch(`${API_BASE_URL}${path}`, options);
      if (response.status === 404 && path !== paths[paths.length - 1]) {
        lastError = new Error(`Endpoint ${path} returned 404.`);
        continue;
      }
      return await readJson(response);
    } catch (error) {
      if (error?.status === 404 && path !== paths[paths.length - 1]) {
        lastError = error;
        continue;
      }
      throw error;
    }
  }
  throw lastError || new Error('Request failed.');
}

function authHeaders(token) {

  return {

    'Content-Type': 'application/json',

    Authorization: `Bearer ${token}`,

  };

}



function App() {

  const [products, setProducts] = useState([]);

  const [token, setToken] = useState(localStorage.getItem('shopEasyToken') || '');

  const [user, setUser] = useState(() => {

    try {

      return JSON.parse(localStorage.getItem('shopEasyUser') || 'null');

    } catch {

      return null;

    }

  });



  const [loading, setLoading] = useState(true);

  const [error, setError] = useState('');



  const [recentlyViewed, setRecentlyViewed] = useState([]);

  const [continueShopping, setContinueShopping] = useState([]);

  const [cartItems, setCartItems] = useState([]);

  const [wishlistItems, setWishlistItems] = useState([]);



  const [selectedProduct, setSelectedProduct] = useState(null);

  const [activePanel, setActivePanel] = useState(null);

  const [showLogin, setShowLogin] = useState(false);



  const [email, setEmail] = useState('');

  const [password, setPassword] = useState('');

  const [loginLoading, setLoginLoading] = useState(false);

  const [loginError, setLoginError] = useState('');



  const [actionMessage, setActionMessage] = useState('');

  const [actionLoading, setActionLoading] = useState(false);



  const formatPrice = (price) =>

    new Intl.NumberFormat('en-IN').format(Number(price || 0));



  // ---------------------------------------------------------

  // PRODUCTS

  // ---------------------------------------------------------



  useEffect(() => {

    let cancelled = false;



    const loadProducts = async () => {

      try {

        setLoading(true);

        setError('');



        const response = await fetch(

          `${API_BASE_URL}/products?limit=20`

        );

        const result = await readJson(response);

        const items = result.data?.items || result.data?.products || result.items || result.products || [];



        if (!cancelled) {

          setProducts(items);

        }

      } catch (err) {

        console.error('Products error:', err);

        if (!cancelled) {

          setError(err.message || 'Unable to load products.');

        }

      } finally {

        if (!cancelled) setLoading(false);

      }

    };



    loadProducts();

    return () => {

      cancelled = true;

    };

  }, []);



  // ---------------------------------------------------------

  // AUTHENTICATED DATA

  // ---------------------------------------------------------



  useEffect(() => {

    if (!token) {

      setRecentlyViewed([]);

      setContinueShopping([]);

      setCartItems([]);

      setWishlistItems([]);

      return;

    }



    loadAllUserData();

  }, [token]);



  const loadRecentlyViewed = async () => {

    if (!token) return;



    try {

      const response = await fetch(

        `${API_BASE_URL}/recently-viewed`,

        { headers: { Authorization: `Bearer ${token}` } }

      );

      const result = await readJson(response);

      setRecentlyViewed(result.data?.items || result.data?.products || result.items || result.products || []);

    } catch (err) {

      console.error('Recently viewed error:', err);

    }

  };



  const loadContinueShopping = async () => {

    if (!token) return;



    try {

      const response = await fetch(

        `${API_BASE_URL}/continue-shopping`,

        { headers: { Authorization: `Bearer ${token}` } }

      );

      const result = await readJson(response);

      setContinueShopping(result.data?.items || []);

    } catch (err) {

      console.error('Continue shopping error:', err);

      setContinueShopping([]);

    }

  };



  const loadCart = async () => {

    if (!token) return;



    try {

      const response = await fetch(

        `${API_BASE_URL}/cart`,

        { headers: { Authorization: `Bearer ${token}` } }

      );

      const result = await readJson(response);

      setCartItems(result.data?.cart?.items || []);

    } catch (err) {

      console.error('Cart error:', err);

      setCartItems([]);

    }

  };



  const loadWishlist = async () => {

    if (!token) return;



    try {

      const response = await fetch(

        `${API_BASE_URL}/wishlist`,

        { headers: { Authorization: `Bearer ${token}` } }

      );

      const result = await readJson(response);

      setWishlistItems(result.data?.wishlist?.items || []);

    } catch (err) {

      console.error('Wishlist error:', err);

      setWishlistItems([]);

    }

  };



  const loadAllUserData = async () => {

    await Promise.all([

      loadRecentlyViewed(),

      loadContinueShopping(),

      loadCart(),

      loadWishlist(),

    ]);

  };



  // ---------------------------------------------------------

  // PRODUCT VIEW

  // ---------------------------------------------------------



  const handleProductClick = async (product) => {

    setSelectedProduct(product);

    setActivePanel(null);

    setActionMessage('');



    if (!token) return;



    try {

      const response = await fetch(

        `${API_BASE_URL}/recently-viewed`,

        {

          method: 'POST',

          headers: authHeaders(token),

          body: JSON.stringify({ productId: product._id }),

        }

      );



      await readJson(response);

      await Promise.all([

        loadRecentlyViewed(),

        loadContinueShopping(),

      ]);

    } catch (err) {

      console.error('Failed to record product view:', err);

    }

  };



  // ---------------------------------------------------------

  // LOGIN

  // ---------------------------------------------------------



  const handleLogin = async (event) => {

    event.preventDefault();



    if (!email.trim() || !password) {

      setLoginError('Please enter your email and password.');

      return;

    }



    try {

      setLoginLoading(true);

      setLoginError('');



      const response = await fetch(

        `${API_BASE_URL}/auth/login`,

        {

          method: 'POST',

          headers: { 'Content-Type': 'application/json' },

          body: JSON.stringify({

            email: email.trim(),

            password,

          }),

        }

      );



      const result = await readJson(response);

      const newToken = result.data?.token || result.token;

      const newUser = result.data?.user || result.user;



      if (!newToken) {

        throw new Error('Login succeeded but no token was returned.');

      }



      localStorage.setItem('shopEasyToken', newToken);

      if (newUser) {

        localStorage.setItem(

          'shopEasyUser',

          JSON.stringify(newUser)

        );

      }



      setToken(newToken);

      setUser(newUser || null);

      setEmail('');

      setPassword('');

      setLoginError('');

      setShowLogin(false);



      // Load authenticated data immediately after login.

      setTimeout(() => {

        loadAllUserData();

      }, 0);

    } catch (err) {

      console.error('Login error:', err);

      setLoginError(err.message || 'Login failed. Please try again.');

    } finally {

      setLoginLoading(false);

    }

  };



  const handleLogout = () => {

    localStorage.removeItem('shopEasyToken');

    localStorage.removeItem('shopEasyUser');



    setToken('');

    setUser(null);

    setRecentlyViewed([]);

    setContinueShopping([]);

    setCartItems([]);

    setWishlistItems([]);

    setSelectedProduct(null);

    setActivePanel(null);

  };



  // ---------------------------------------------------------

  // CART

  // ---------------------------------------------------------



  const addToCart = async (product) => {

    if (!token) {

      setSelectedProduct(null);

      setShowLogin(true);

      return;

    }



    try {

      setActionLoading(true);

      setActionMessage('');



      const result = await postWithFallback(
        ['/cart', '/cart/add'],
        {
          method: 'POST',
          headers: authHeaders(token),
          body: JSON.stringify({ productId: product._id, quantity: 1 }),
        }
      );



      setCartItems(result.data?.cart?.items || []);

      setActionMessage('Added to cart.');

    } catch (err) {

      console.error('Add to cart error:', err);

      setActionMessage(err.message || 'Failed to add to cart.');

    } finally {

      setActionLoading(false);

    }

  };



  const removeFromCart = async (productId) => {

    try {

      setActionLoading(true);



      const response = await fetch(

        `${API_BASE_URL}/cart/${productId}`,

        {

          method: 'DELETE',

          headers: {

            Authorization: `Bearer ${token}`,

          },

        }

      );



      await readJson(response);

      await loadCart();

    } catch (err) {

      console.error('Remove cart error:', err);

    } finally {

      setActionLoading(false);

    }

  };



  // ---------------------------------------------------------

  // WISHLIST

  // ---------------------------------------------------------



  const addToWishlist = async (product) => {

    if (!token) {

      setSelectedProduct(null);

      setShowLogin(true);

      return;

    }



    try {

      setActionLoading(true);

      setActionMessage('');



      const result = await postWithFallback(
        ['/wishlist', '/wishlist/add'],
        {
          method: 'POST',
          headers: authHeaders(token),
          body: JSON.stringify({ productId: product._id }),
        }
      );



      setWishlistItems(

        result.data?.wishlist?.items || []

      );

      setActionMessage('Added to wishlist.');

    } catch (err) {

      console.error('Add to wishlist error:', err);

      setActionMessage(

        err.message || 'Failed to add to wishlist.'

      );

    } finally {

      setActionLoading(false);

    }

  };



  const removeFromWishlist = async (productId) => {

    try {

      setActionLoading(true);



      const response = await fetch(

        `${API_BASE_URL}/wishlist/${productId}`,

        {

          method: 'DELETE',

          headers: {

            Authorization: `Bearer ${token}`,

          },

        }

      );



      await readJson(response);

      await loadWishlist();

    } catch (err) {

      console.error('Remove wishlist error:', err);

    } finally {

      setActionLoading(false);

    }

  };



  // ---------------------------------------------------------

  // QUICK ACCESS PANELS

  // ---------------------------------------------------------



  const openPanel = async (type) => {

    if (!token) {

      setShowLogin(true);

      return;

    }



    setSelectedProduct(null);

    setActionMessage('');

    setActivePanel(type);



    if (type === 'recent') await loadRecentlyViewed();

    if (type === 'continue') await loadContinueShopping();

    if (type === 'cart') await loadCart();

    if (type === 'wishlist') await loadWishlist();

  };



  // ---------------------------------------------------------

  // LOADING / ERROR

  // ---------------------------------------------------------



  if (loading) {

    return (

      <div className="app loading-page">

        <div className="loading-content">

          <div className="loading-icon">🛍️</div>

          <h2>Loading ShopEasy...</h2>

          <p>Please wait while we load the products.</p>

        </div>

      </div>

    );

  }



  if (error) {

    return (

      <div className="app loading-page">

        <div className="error-box">

          <div className="error-icon">⚠️</div>

          <h2>Something went wrong</h2>

          <p>{error}</p>

          <button

            className="primary-button"

            onClick={() => window.location.reload()}

          >

            Try Again

          </button>

        </div>

      </div>

    );

  }



  // ---------------------------------------------------------

  // MAIN PAGE

  // ---------------------------------------------------------



  return (

    <div className="app">

      <main className="app-shell">



        <header className="header">

          <div className="brand-area">

            <h1 className="app-title">

              Shop<span>Easy</span>

            </h1>

            <p className="subtitle">

              {token

                ? `Welcome back${

                    user?.name ? `, ${user.name}` : ''

                  }`

                : 'Browsing as guest'}

            </p>

          </div>



          <div className="header-actions">

            {token ? (

              <button

                className="login-button"

                onClick={handleLogout}

              >

                Logout

              </button>

            ) : (

              <button

                className="login-button"

                onClick={() => {

                  setLoginError('');

                  setShowLogin(true);

                }}

              >

                Login

              </button>

            )}

          </div>

        </header>



        <section className="quick-access">

          <div className="section-heading">

            <div>

              <h2>Quick Access</h2>

              <p>Manage your shopping activity</p>

            </div>

            <span className="shortcut-count">4 shortcuts</span>

          </div>



          <div className="quick-grid">

            <button

              className="quick-card recent-card"

              onClick={() => openPanel('recent')}

            >

              <div className="quick-icon">🕘</div>

              <div>

                <h3>Recently Viewed</h3>

                <p>Your browsing history</p>

              </div>

              <span className="quick-arrow">→</span>

            </button>



            <button

              className="quick-card continue-card"

              onClick={() => openPanel('continue')}

            >

              <div className="quick-icon">🛍️</div>

              <div>

                <h3>Continue Shopping</h3>

                <p>Pick up where you left off</p>

              </div>

              <span className="quick-arrow">→</span>

            </button>



            <button

              className="quick-card cart-card"

              onClick={() => openPanel('cart')}

            >

              <div className="quick-icon">🛒</div>

              <div>

                <h3>Cart</h3>

                <p>Your selected products</p>

              </div>

              <span className="quick-arrow">→</span>

            </button>



            <button

              className="quick-card wishlist-card"

              onClick={() => openPanel('wishlist')}

            >

              <div className="quick-icon">❤️</div>

              <div>

                <h3>Wishlist</h3>

                <p>Your saved products</p>

              </div>

              <span className="quick-arrow">→</span>

            </button>

          </div>

        </section>



        <section className="products-section">

          <div className="section-heading">

            <div>

              <h2>All Products</h2>

              <p>{products.length} products available</p>

            </div>

          </div>



          <div className="product-grid">

            {products.map((product) => (

              <article

                className="product-card"

                key={product._id}

                onClick={() => handleProductClick(product)}

              >

                <div className="product-image-wrapper">

                  <img

                    src={product.image}

                    alt={product.name}

                    className="product-image"

                  />

                </div>



                <div className="product-info">

                  <span className="product-category">

                    {product.category}

                  </span>



                  <h3>{product.name}</h3>



                  <p className="product-description">

                    {product.description}

                  </p>



                  <div className="product-bottom">

                    <strong>

                      ₹{formatPrice(product.price)}

                    </strong>

                    <span>Tap to view product →</span>

                  </div>

                </div>

              </article>

            ))}

          </div>

        </section>

      </main>



      {/* PRODUCT DETAIL */}

      {selectedProduct && (

        <div

          className="modal-overlay"

          onClick={() => setSelectedProduct(null)}

        >

          <div

            className="product-detail-modal"

            onClick={(event) => event.stopPropagation()}

          >

            <button

              className="modal-close"

              onClick={() => setSelectedProduct(null)}

            >

              ×

            </button>



            <div className="detail-image">

              <img

                src={selectedProduct.image}

                alt={selectedProduct.name}

              />

            </div>



            <div className="detail-content">

              <span className="detail-category">

                {selectedProduct.category}

              </span>



              <h2>{selectedProduct.name}</h2>



              <p className="detail-description">

                {selectedProduct.description}

              </p>



              <div className="detail-price">

                ₹{formatPrice(selectedProduct.price)}

              </div>



              <div className="detail-stock">

                <strong>Stock:</strong>{' '}

                {selectedProduct.stock}

              </div>



              {actionMessage && (

                <div className="success-message">

                  {actionMessage}

                </div>

              )}



              <div className="detail-actions">

                <button

                  className="wishlist-action"

                  disabled={actionLoading}

                  onClick={() =>

                    addToWishlist(selectedProduct)

                  }

                >

                  ♡ &nbsp; Add to Wishlist

                </button>



                <button

                  className="cart-action"

                  disabled={actionLoading}

                  onClick={() =>

                    addToCart(selectedProduct)

                  }

                >

                  🛒 &nbsp; Add to Cart

                </button>

              </div>

            </div>

          </div>

        </div>

      )}



      {/* QUICK ACCESS PANEL */}

      {activePanel && (

        <div

          className="modal-overlay"

          onClick={() => setActivePanel(null)}

        >

          <div

            className="panel-modal"

            onClick={(event) => event.stopPropagation()}

          >

            <button

              className="modal-close"

              onClick={() => setActivePanel(null)}

            >

              ×

            </button>



            {activePanel === 'recent' && (

              <>

                <h2>Recently Viewed</h2>

                <p className="panel-subtitle">

                  Your latest product activity

                </p>



                {recentlyViewed.length === 0 ? (

                  <div className="panel-empty">

                    🕘

                    <h3>No recently viewed products</h3>

                    <p>

                      Open a product to build your browsing history.

                    </p>

                  </div>

                ) : (

                  <div className="panel-product-grid">

                    {recentlyViewed.map((item) => {

                      const product = item.productId || item.product || item;

                      if (!product?._id) return null;



                      return (

                        <button

                          className="panel-product"

                          key={product._id}

                          onClick={() => handleProductClick(product)}

                        >

                          <img

                            src={product.image}

                            alt={product.name}

                          />

                          <strong>{product.name}</strong>

                          <span>

                            ₹{formatPrice(product.price)}

                          </span>

                        </button>

                      );

                    })}

                  </div>

                )}

              </>

            )}



            {activePanel === 'continue' && (

              <>

                <h2>Continue Shopping</h2>

                <p className="panel-subtitle">

                  Products you've viewed but haven't purchased

                </p>



                {continueShopping.length === 0 ? (

                  <div className="panel-empty">

                    🛍️

                    <h3>Nothing to continue yet</h3>

                    <p>

                      View products and they will appear here until purchased.

                    </p>

                  </div>

                ) : (

                  <div className="panel-product-grid">

                    {continueShopping.map((item) => {

                      const product = item.product;

                      if (!product?._id) return null;



                      return (

                        <button

                          className="panel-product"

                          key={product._id}

                          onClick={() => handleProductClick(product)}

                        >

                          <img

                            src={product.image}

                            alt={product.name}

                          />

                          <strong>{product.name}</strong>

                          <span>

                            ₹{formatPrice(product.price)}

                          </span>

                        </button>

                      );

                    })}

                  </div>

                )}

              </>

            )}



            {activePanel === 'cart' && (

              <>

                <h2>Cart</h2>

                <p className="panel-subtitle">

                  Your selected products

                </p>



                {cartItems.length === 0 ? (

                  <div className="panel-empty">

                    🛒

                    <h3>Your cart is empty</h3>

                    <p>Add products from their detail page.</p>

                  </div>

                ) : (

                  <div className="list-items">

                    {cartItems.map((item) => {

                      const product = item.productId;

                      if (!product?._id) return null;



                      return (

                        <div className="list-item" key={product._id}>

                          <img

                            src={product.image}

                            alt={product.name}

                          />

                          <div className="list-item-info">

                            <strong>{product.name}</strong>

                            <span>

                              ₹{formatPrice(product.price)} × {item.quantity}

                            </span>

                          </div>

                          <button

                            className="remove-button"

                            disabled={actionLoading}

                            onClick={() =>

                              removeFromCart(product._id)

                            }

                          >

                            Remove

                          </button>

                        </div>

                      );

                    })}

                  </div>

                )}

              </>

            )}



            {activePanel === 'wishlist' && (

              <>

                <h2>Wishlist</h2>

                <p className="panel-subtitle">

                  Your saved products

                </p>



                {wishlistItems.length === 0 ? (

                  <div className="panel-empty">

                    ❤️

                    <h3>Your wishlist is empty</h3>

                    <p>

                      Save products from their detail page.

                    </p>

                  </div>

                ) : (

                  <div className="panel-product-grid">

                    {wishlistItems.map((product) => {

                      if (!product?._id) return null;



                      return (

                        <div

                          className="wishlist-panel-item"

                          key={product._id}

                        >

                          <button

                            className="panel-product"

                            onClick={() =>

                              handleProductClick(product)

                            }

                          >

                            <img

                              src={product.image}

                              alt={product.name}

                            />

                            <strong>{product.name}</strong>

                            <span>

                              ₹{formatPrice(product.price)}

                            </span>

                          </button>



                          <button

                            className="remove-button"

                            disabled={actionLoading}

                            onClick={() =>

                              removeFromWishlist(product._id)

                            }

                          >

                            Remove

                          </button>

                        </div>

                      );

                    })}

                  </div>

                )}

              </>

            )}

          </div>

        </div>

      )}



      {/* LOGIN */}

      {showLogin && (

        <div

          className="modal-overlay"

          onClick={() => {

            if (!loginLoading) {

              setShowLogin(false);

              setLoginError('');

            }

          }}

        >

          <div

            className="login-modal"

            onClick={(event) => event.stopPropagation()}

          >

            <button

              className="modal-close"

              onClick={() => {

                if (!loginLoading) {

                  setShowLogin(false);

                  setLoginError('');

                }

              }}

            >

              ×

            </button>



            <div className="login-icon">🛍️</div>



            <h2>Welcome to ShopEasy</h2>



            <p className="login-subtitle">

              Login to continue shopping

            </p>



            <form onSubmit={handleLogin}>

              <div className="form-group">

                <label htmlFor="email">Email</label>

                <input

                  id="email"

                  type="email"

                  value={email}

                  onChange={(event) =>

                    setEmail(event.target.value)

                  }

                  placeholder="Enter your email"

                  disabled={loginLoading}

                  required

                />

              </div>



              <div className="form-group">

                <label htmlFor="password">Password</label>

                <input

                  id="password"

                  type="password"

                  value={password}

                  onChange={(event) =>

                    setPassword(event.target.value)

                  }

                  placeholder="Enter your password"

                  disabled={loginLoading}

                  required

                />

              </div>



              {loginError && (

                <div className="login-error">

                  {loginError}

                </div>

              )}



              <button

                type="submit"

                className="primary-button login-submit"

                disabled={loginLoading}

              >

                {loginLoading ? 'Logging in...' : 'Login'}

              </button>

            </form>

          </div>

        </div>

      )}

    </div>

  );

}



export default App;
